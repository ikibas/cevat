/*
 * AppTest.java
 *
 * Version 1.0
 *
 * 4/10/2021
 *
 * Copyrighted
 */

package com.mycompany.app;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.Assert;
import org.junit.Test;

/**
 *
 Class description Unit test.
 *
 * @version 1.0 10 April 2021  * @Cevat Ikibas
 */
public class AppTest {
    /**
     * explanation..
     *
     *
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
    /**
     * explanation..
     *
     *
     */
    @Test
    public void testCalculateRectangleTest() {
        CalculateRectangle testerCalculateRectangleArea = new CalculateRectangle(4, 5);
        Assert.assertEquals("Result must be 20 for 4 and 5", 20.0, testerCalculateRectangleArea.calculateArea(), 0.0);

    }
    /**
     * explanation..
     *
     *
     */
    @Test
    public void testCalculateRectangelcarpetCostTest() {
        CalculateRectangle calculateRectangle = new CalculateRectangle(4, 5);
        RectangleCarpet testerRectangCarpetCost = new RectangleCarpet(calculateRectangle, 8);
        Assert.assertEquals("Result must be 160 for 4 and 5 carpet", 160.0, testerRectangCarpetCost.getTotalCost(), 0.0);

    }
}