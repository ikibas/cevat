/*
 * CalculationOfArea.java
 *
 * Version 1.0
 *
 * 4/10/2021
 *
 * Copyrighted
 */

package com.mycompany.app;
/**
 *
 *this is the interface the other classes uses for calculation.
 *
 *@version 1.0 10 April 2021  * @Cevat Ikibas
 */

interface CalculationOfArea {
    /**
     *function to be implemented.
      * @return  area of shape
     */
   public double calculateArea();
}
