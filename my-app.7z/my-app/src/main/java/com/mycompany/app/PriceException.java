/*
 * PriceException.java
 *
 * Version 1.0
 *
 * 4/10/2021
 *
 * Copyrighted
 */

package com.mycompany.app;
/**
 *
 *Class description , this is the custom exception
 * class used in cost calculation.
 *
 * @version 1.0 10 April 2021  * @Cevat Ikibas
 */

public class PriceException  extends Exception {
    /**
     * calculate the area of square..
     *
     *@return  exception string...
     */

    public String toString() {
        return "Error. Price can not be negative";
    }
}
