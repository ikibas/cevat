/*
 * SquareCarpet.java
 *
 * Version 1.0
 *
 * 4/10/2021
 *
 * Copyrighted
 */
package com.mycompany.app;

/**
 *
 *Class description , this calss is used to show how
 * the other classes are extended.
 *
 * @version 1.0 10 April 2021  * @Cevat Ikibas
 */

public class SquareCarpet extends CalculateSquare {
    /**
     * carpet class for square shape.
     *classVar pricePerSq
     @param pricePerSq price per sequare
     */
   private double pricePerSq;

    /**
     * explanation.
     * @return pricePerSq
     *
     */
    public double getPricePerSq() {
        return pricePerSq;
    }

    /**
     * explanation.
     * @param pricePerSq1  explanation
     *
     */
    public void setPricePerSq(double pricePerSq1) {
        this.pricePerSq = pricePerSq1;
    }

    /**
     * explanation.
     * @param side1 explanation
     * @param pricePerSq1 expalanation
     */
    public SquareCarpet(double side1, double pricePerSq1) {
        super(side1);
        this.pricePerSq = pricePerSq1;
    }
    /**
     * calculate the price of square carpet..
     *
     *@return  price of square carpet...
     */
    public double calcPrice() {

        try {
            if (pricePerSq <= 0) {
                throw new PriceException();
            }
        } catch (PriceException e) {
            System.out.println("Exception " + e.toString());
        }
        return this.calculateArea() * pricePerSq;
    }

}
