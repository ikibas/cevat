/*
 * CalculateRectangle.java
 *
 * Version 1.0
 *
 * 4/10/2021
 *
 * Copyrighted
 */

package com.mycompany.app;

/**
 *
 Class description xyz.
 *
 * @version 1.0 10 April 2021  * @Cevat Ikibas
 */

public class CalculateRectangle implements CalculationOfArea {
    /**
     * class isused for rectangle shapes.
    * classVar length, width.
     *@param length length of rect
     *@param widt width of rect
     */

   private double length;
   private double width;

    /**
     * constructor.
     * @param length1  explanation
     * @param width1  expalanation
     * return  no return...
     */
        public CalculateRectangle(double length1, double width1) {
        this.length = length1;
        this.width = width1;
    }
    /**
     * explanation.
     *
     *@return length
     */
    public double getLength() {
        return length;
    }
    /**
     * explanation.
     *
     * @param length1  expalanation
     */
    public void setLength(double length1) {
        this.length = length1;
    }
    /**
     * explanation.
     *@return width
     *
     */
    public double getWidth() {
        return width;
    }
    /**
     * explanation.
     * @param width1 expalanation
     *
     */
    public void setWidth(double width1) {
        this.width = width1;
    }

    /**
     * calculate the area of rectangle..
     *
     *@return  area of rectangle...
     */
    public double calculateArea() {
        try {
            if ((length <= 0) || (width <= 0)) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return length * width;
    }
}
