/*
 * main.java
 *
 * Version 1.0
 *
 * 4/10/2021
 *
 * Copyrighted
 */

package com.mycompany.app;
/**
 * main class for testing the implementation.
 *
 */
class App {
    /**
     * calculate the total cost of rectangle carpet.
     * @param args  expalanation
     *return  no return...
     */
    public static void main(String[] args) {
    }
}
