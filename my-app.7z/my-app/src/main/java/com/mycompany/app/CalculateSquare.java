/*
 * CalculateSquare.java
 *
 * Version 1.0
 *
 * 4/10/2021
 *
 * Copyrighted
 */

package com.mycompany.app;

/**
 *
 Class description xyz.
 *
 * @version 1.0 10 April 2021  * @Cevat Ikibas
 */

public class CalculateSquare implements CalculationOfArea {
    /**
     *classVar side.
     *@param side side of square
     */
    private double side;

    /**
     * constructor..
     * @param side1  expalanation
     * return  no return value...
     */
    public CalculateSquare(double side1) {
        this.side = side1;
    }
    /**
     * explanation.
     *@return side
     *
     */
    public double getSide() {
        return side;
    }
    /**
     * explanation.
     *
     * @param side1  expalanation
     */
    public void setSide(double side1) {
        this.side = side1;
    }

    /**
     * calculate the area of square.
     *
     *@return  area of square...
     */
    public double calculateArea() {
        try {
            if (side <= 0) {
                throw new RuntimeException();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return side * side;
    }
}
