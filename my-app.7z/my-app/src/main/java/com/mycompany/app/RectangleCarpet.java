/*
 * rectangleCarpet.java
 *
 * Version 1.0
 *
 * 4/10/2021
 *
 * Copyrighted
 */

package com.mycompany.app;
/**
 *
 *Class description: this class is used to show using othe class
 * object as variable in another class to show
 * interaction between the classes.
 *
 *@version 1.0 10 April 2021  * @Cevat Ikibas
 */

public class RectangleCarpet {
    /**
     *classVar calculateRectangle, pricePerSq.
     *
     */

   private CalculateRectangle calculateRectangle;
   private double pricePerSq;

    /**
     * explanation.
     * @return  calculateRectangle
     *
     */
    public CalculateRectangle getCalculateRectangle() {
        return calculateRectangle;
    }
    /**
     * explanation.
     * @param calculateRectangle1 explanation
     *
     */
    public void setCalculateRectangle(CalculateRectangle calculateRectangle1) {
        this.calculateRectangle = calculateRectangle1;
    }
    /**
     * explanation.
     * @return pricePerSq
     *
     */
    public double getPricePerSq() {
        return pricePerSq;
    }
    /**
     * explanation.
     * @param pricePerSq1 explanation
     *
     */
    public void setPricePerSq(double pricePerSq1) {
        this.pricePerSq = pricePerSq1;
    }

    /**
     * calculate the total cost of rectangle carpet..
     *
     *@return  area of square...
     */
    public double getTotalCost() {
        try {
            if (pricePerSq <= 0) {
                throw new PriceException();
            }
        } catch (PriceException e) {
            System.out.println("Exception " + e.toString());
        }
    return calculateRectangle.calculateArea() * pricePerSq;
    }
    /**
     * explanation..
     * @param calculateRectangle1 expalanation
     * @param pricePerSq1  expalanation
     *
     */
    public RectangleCarpet(CalculateRectangle calculateRectangle1,
                           double pricePerSq1) {
        this.calculateRectangle = calculateRectangle1;
        this.pricePerSq = pricePerSq1;
    }
}

